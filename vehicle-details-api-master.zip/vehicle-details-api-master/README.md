# India Vehicle Details API

 The API is intended to fetch details of a vehicle corresponding to the vehicle number. The API is written in Node.JS and is extremely simple. It scrapes data from https://parivahan.gov.in/. 

# Usage

 In order to setup the script, just clone the repository, run command `npm i` and then run `npm start`.
